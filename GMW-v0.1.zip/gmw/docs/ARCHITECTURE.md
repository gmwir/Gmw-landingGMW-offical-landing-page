# معماری و مسیر توسعهٔ Backend

## وضعیت فعلی
سایت ایستا + `core.js` (قوانین) + `localStorage`. قوانین کسب‌وکار در `core.js` جداست تا بدون بازنویسی ذهنی به سرور منتقل شود.

## مدل دادهٔ هدف (پایگاه داده)
| جدول | نکات کلیدی |
|---|---|
| customers | phone یکتا؛ name, city |
| scratch_codes | code یکتا؛ status(unused/used)؛ used_by — **UNIQUE + به‌روزرسانی اتمی `WHERE status='unused'`** |
| warranties | tracking_code یکتا؛ serial_key **UNIQUE**؛ invoice_file_id؛ status(pending_review/active/rejected) |
| parts | name, group, price, liability_limit, max_replacements, active (قابل‌ویرایش توسط مدیر) |
| coverage_requests | tracking_code، owner_*، parts (جدول واسط)، total، status، technician_id، decision_reason، start/end |
| payments / refunds | payment: amount, kind(demo/gateway), status؛ refund: payment_id, amount (کامل), reason, status |
| technicians, service_centers | شهر، تماس، وضعیت قرارداد |
| brake_enrollments | phone, start_date, source(coverage/club), quota_overrides |
| brake_quota_policy | plan_year(1..3) → quota — **سهمیهٔ هر سال جداگانه** |
| brake_requests / brake_history | plan_year، pad_class، pad_price، labor_fee (جدا)، center، seq |
| tire_requests, basket_interests, insurance_requests, contacts | شامل `consent_notify` و زمان رضایت |
| club_members | consent_marketing + consent_at؛ vehicles؛ linked_codes |
| audit_log | actor، action، entity، id، before/after، زمان — **فقط‌افزودنی** |

## قوانین که باید سمت سرور اعمال شوند
1. مصرف کد اسکرچ و ثبت سریال: داخل یک تراکنش با قید UNIQUE (جلوگیری از race).
2. سهمیهٔ لنت: شمارش درخواست‌های فعال در همان `plan_year` داخل تراکنش (قفل ردیف عضویت).
3. رد درخواست پوشش ⇒ ایجاد بازپرداخت **کامل** و تغییر وضعیت پرداخت؛ بازپرداخت دوباره ممنوع.
4. تغییر قیمت/سهمیه/سقف ⇒ ثبت در audit_log با مقدار قبل و بعد.

## احراز هویت و دسترسی
- مشتری: OTP پیامکی (پس از فعال‌سازی سرویس پیامک با تأیید مالک).
- مدیریت: ورود امن + RBAC سمت سرور. نقش‌ها: owner, finance, support, ops (نگاشت در `admin.js`، فقط برای نمایش).
- محدودیت نرخ درخواست و CAPTCHA برای فرم‌های عمومی و استعلام کد.

## اتصال‌های آینده (همه غیرفعال و نیازمند تأیید صریح)
- درگاه پرداخت: جایگزینی «پرداخت آزمایشی»؛ ثبت `payments.kind='gateway'`.
- پیامک: اطلاع‌رسانی فقط برای رکوردهای دارای رضایت.
- AI: `ai-adapter.js` رابط `diagnose()` دارد؛ provider جدید فقط از طریق Backend (کلید API در مرورگر نباشد)، با سقف هزینه و لاگ.
- ذخیرهٔ تصویر فاکتور: ذخیره‌سازی شیء (object storage) با اسکن نوع/حجم.

## سئو
URL خوانا، `title/description/canonical` در هر صفحه، یک `h1`، `sitemap.xml`، `robots.txt`، JSON-LD فقط Organization/WebSite/FAQPage (بدون rating/price/تلفن ساختگی)، `/admin/` با noindex. دامنهٔ نهایی را با `SITE_URL` بدهید.
