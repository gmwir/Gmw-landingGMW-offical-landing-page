// قالب مشترک، آیکون‌ها و کمک‌های ساخت فرم — GMW
export const SITE_NAME = 'GMW';
export const SITE_URL = process.env.SITE_URL || 'https://gmw.example'; // جایگزین دامنهٔ واقعی پس از تأیید

export const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

const ICONS = {
  shield: '<path d="M12 3l8 3v6c0 4.5-3.2 8-8 9-4.8-1-8-4.5-8-9V6z"/><path d="M8.5 12l2.5 2.5L15.5 10"/>',
  ledger: '<rect x="4" y="3" width="16" height="18" rx="2"/><path d="M8 8h8M8 12h8M8 16h5"/>',
  crown: '<path d="M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z"/>',
  basket: '<path d="M4 9h16l-1.6 10a2 2 0 01-2 1.7H7.6a2 2 0 01-2-1.7z"/><path d="M8 9l3-5M16 9l-3-5"/>',
  tire: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="3.5"/><path d="M12 3v5.5M12 15.5V21M3 12h5.5M15.5 12H21"/>',
  cpu: '<rect x="5" y="5" width="14" height="14" rx="3"/><path d="M9 2v3M15 2v3M9 19v3M15 19v3M2 9h3M2 15h3M19 9h3M19 15h3"/><path d="M9.5 12h5"/>',
  umbrella: '<path d="M3 12a9 9 0 0118 0z"/><path d="M12 12v6a2 2 0 004 0"/>',
  mail: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3.5 7l8.5 6 8.5-6"/>',
  brake: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="4"/><path d="M5 5l2.5 2.5M19 5l-2.5 2.5M5 19l2.5-2.5M19 19l-2.5-2.5"/>',
  layers: '<path d="M12 3l9 5-9 5-9-5z"/><path d="M3 13l9 5 9-5"/>',
  menu: '<path d="M4 7h16M4 12h16M4 17h16"/>',
  close: '<path d="M6 6l12 12M18 6L6 18"/>',
  check: '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
  arrow: '<path d="M15 6l-6 6 6 6"/>',
  user: '<circle cx="12" cy="8" r="4"/><path d="M4 21c1-4 4-6 8-6s7 2 8 6"/>'
};
const sprite = '<svg width="0" height="0" style="position:absolute" aria-hidden="true"><defs>' +
  Object.entries(ICONS).map(([k, v]) => `<symbol id="i-${k}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">${v}</symbol>`).join('') +
  '</defs></svg>';
export const icon = (n, cls = '') => `<svg class="ic ${cls}" aria-hidden="true"><use href="#i-${n}"/></svg>`;

export const SERVICES = [
  { slug: 'warranty', icon: 'shield', title: 'فعال‌سازی و استعلام گارانتی', text: 'کد اسکرچ را ثبت کنید، اصالت قطعه را بسنجید و کد رهگیری بگیرید.' },
  { slug: 'transparent-fund', icon: 'ledger', title: 'صندوق شفاف گارانتی', text: 'مسیر رسیدگی به پرونده‌ها را از خرید تا پرداخت ببینید.' },
  { slug: 'club', icon: 'crown', title: 'باشگاه مشتریان', text: 'عضویت با موبایل، سوابق خدمات و پیشنهادهای مرتبط با خودروی شما.' },
  { slug: 'economy-basket', icon: 'basket', title: 'سبد اقتصادی لوازم مصرفی خودرو', text: 'لنت، روغن، فیلتر و شمع؛ ثبت علاقه‌مندی و اطلاع از آماده‌شدن سبد.' },
  { slug: 'tire', icon: 'tire', title: 'ثبت‌نام لاستیک حواله‌ای', text: 'سایز و برند را ثبت کنید تا با فراهم‌شدن امکان ثبت‌نام خبردار شوید.' },
  { slug: 'ai-engineer', icon: 'cpu', title: 'مهندس خودرو مبتنی بر هوش مصنوعی', text: 'علائم خودرو را بنویسید؛ علت‌های احتمالی و میزان فوریت را ببینید.' },
  { slug: 'insurance-discount', icon: 'umbrella', title: 'تخفیف بیمه ویژه اعضا', text: 'درخواست خود را ثبت کنید تا در صورت برقراری همکاری، اطلاع دهیم.' },
  { slug: 'contact', icon: 'mail', title: 'ارتباط با ما', text: 'پیام، پیشنهاد یا پیگیری؛ پاسخ‌گوی شما هستیم.' }
];

const NAV = [
  ['/warranty/', 'گارانتی'], ['/coverage-plan/', 'طرح سه‌ساله'], ['/brake-service/', 'خدمات لنت'],
  ['/club/', 'باشگاه'], ['/ai-engineer/', 'مهندس خودرو'], ['/contact/', 'تماس']
];

const CITIES = ['تهران', 'مشهد', 'اصفهان', 'شیراز', 'تبریز', 'کرج', 'قم', 'اهواز', 'کرمانشاه', 'ارومیه', 'رشت', 'زاهدان', 'همدان', 'کرمان', 'یزد', 'اردبیل', 'بندرعباس', 'اراک', 'سنندج', 'قزوین'];
const CARS = ['پژو ۲۰۶', 'پژو ۲۰۷', 'پژو ۴۰۵', 'پژو پارس', 'سمند', 'دنا', 'رانا', 'تیبا', 'ساینا', 'کوییک', 'پراید', 'شاهین', 'سورن', 'هایما S7', 'تارا', 'ریرا', 'MVM 315', 'MVM X22', 'ال ۹۰', 'سیتروئن زانتیا'];
export const dl = () => `<datalist id="cities">${CITIES.map((c) => `<option value="${c}">`).join('')}</datalist><datalist id="cars">${CARS.map((c) => `<option value="${c}">`).join('')}</datalist>`;

/* ---------- کمک‌های فرم ---------- */
const fa = (n) => String(n).replace(/\d/g, (d) => '۰۱۲۳۴۵۶۷۸۹'[d]);
export function field({ name, label, type = 'text', req = true, hint = '', placeholder = '', list = '', attrs = '' }) {
  const t = type === 'tel' ? 'type="tel" inputmode="numeric" autocomplete="tel" dir="ltr"' : `type="${type}"`;
  return `<div class="field"><label for="f-${name}">${label}${req ? '' : ' <span class="opt">(اختیاری)</span>'}</label>` +
    `<input id="f-${name}" name="${name}" ${t} ${req ? 'required' : ''} ${placeholder ? `placeholder="${esc(placeholder)}"` : ''} ${list ? `list="${list}"` : ''} ${attrs}>` +
    `${hint ? `<small class="hint">${hint}</small>` : ''}<small class="err" data-err="${name}" role="alert"></small></div>`;
}
export function select({ name, label, options, req = true, placeholder = 'انتخاب کنید' }) {
  return `<div class="field"><label for="f-${name}">${label}</label><select id="f-${name}" name="${name}" ${req ? 'required' : ''}>` +
    `<option value="">${placeholder}</option>${options.map((o) => (Array.isArray(o) ? `<option value="${esc(o[0])}">${o[1]}</option>` : `<option value="${esc(o)}">${o}</option>`)).join('')}</select>` +
    `<small class="err" data-err="${name}" role="alert"></small></div>`;
}
export function textarea({ name, label, req = false, rows = 4, hint = '' }) {
  return `<div class="field"><label for="f-${name}">${label}${req ? '' : ' <span class="opt">(اختیاری)</span>'}</label><textarea id="f-${name}" name="${name}" rows="${rows}" ${req ? 'required' : ''}></textarea>${hint ? `<small class="hint">${hint}</small>` : ''}<small class="err" data-err="${name}" role="alert"></small></div>`;
}
export function checkbox({ name, label, value = '1' }) {
  return `<div class="field check"><label><input type="checkbox" name="${name}" value="${esc(value)}"> <span>${label}</span></label><small class="err" data-err="${name}" role="alert"></small></div>`;
}
export function yearSelect(name = 'year', label = 'سال ساخت (شمسی)') {
  const opts = []; for (let y = 1405; y >= 1380; y--) opts.push([String(y), fa(y)]);
  return select({ name, label, options: opts });
}
export const resultBox = '<div class="result" role="status" aria-live="polite" hidden></div>';
export const demoBadge = '<span class="badge demo">نمونه نمایشی</span>';

/* ---------- قالب کلی ---------- */
export function layout(page, ctx) {
  const { link, asset } = ctx;
  const canonical = SITE_URL + page.path;
  const title = page.path === '/' ? page.title : `${page.title} | ${SITE_NAME}`;
  const org = { '@context': 'https://schema.org', '@type': 'Organization', name: 'GMW', url: SITE_URL + '/', description: 'پلتفرم ثبت و پیگیری گارانتی، اصالت‌سنجی قطعات و خدمات خودرو (نسخهٔ آزمایشی).' };
  const site = { '@context': 'https://schema.org', '@type': 'WebSite', name: 'GMW', url: SITE_URL + '/', inLanguage: 'fa-IR' };
  const ld = page.noindex ? [] : [org, site].concat(page.jsonld || []);
  const scripts = ['core.js'].concat(page.ai ? ['ai-adapter.js'] : [], page.admin ? ['admin.js'] : ['app.js']).map((s) => `<script defer src="${asset('js/' + s)}"></script>`).join('');
  return `<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>${esc(title)}</title>
<meta name="description" content="${esc(page.desc)}">
${page.noindex ? '<meta name="robots" content="noindex, nofollow">' : '<meta name="robots" content="index, follow">'}
<link rel="canonical" href="${canonical}">
<meta name="theme-color" content="#0b0f14">
<meta property="og:type" content="website"><meta property="og:locale" content="fa_IR"><meta property="og:site_name" content="GMW">
<meta property="og:title" content="${esc(title)}"><meta property="og:description" content="${esc(page.desc)}"><meta property="og:url" content="${canonical}">
<link rel="icon" href="${asset('img/favicon.svg')}" type="image/svg+xml">
<link rel="stylesheet" href="${asset('css/style.css')}">
${ld.map((o) => `<script type="application/ld+json">${JSON.stringify(o)}</script>`).join('\n')}
</head>
<body data-page="${page.id}" data-root="${ctx.root}">
${sprite}
<div class="demo-bar">نسخهٔ آزمایشی — پرداخت، پیامک و هوش مصنوعی واقعی فعال نیست؛ داده‌ها فقط در مرورگر شما می‌ماند.</div>
<header class="site-header">
  <div class="wrap bar">
    <a class="logo" href="${link('/')}" aria-label="GMW — صفحهٔ اصلی"><svg viewBox="0 0 40 40" width="34" height="34" aria-hidden="true"><rect width="40" height="40" rx="11" fill="currentColor"/><path d="M11 24.5c0-5 3-8.5 8.6-8.5 2.2 0 4 .6 5.4 1.6l-1.8 2.7a5 5 0 00-3.4-1.2c-2.7 0-4.2 1.9-4.2 5s1.5 5 4.2 5c1.5 0 2.5-.4 3.1-1v-1.4h-3.6V23H27v6.2c-1.6 1.9-4 3.1-7.4 3.1-5.6 0-8.6-3.2-8.6-7.8z" fill="#fff"/></svg><b>GMW</b></a>
    <nav class="nav" id="nav" aria-label="منوی اصلی">${NAV.map(([p, t]) => `<a href="${link(p)}"${page.path === p ? ' aria-current="page"' : ''}>${t}</a>`).join('')}</nav>
    <a class="btn small" id="login-btn" href="${link('/club/')}">${icon('user')}<span>ورود / عضویت</span></a>
    <button class="menu-btn" id="menu-btn" aria-label="منو" aria-expanded="false" aria-controls="nav">${icon('menu')}</button>
  </div>
</header>
<main id="main">
${page.body(ctx)}
</main>
<footer class="site-footer">
  <div class="wrap">
    <div class="foot-grid">
      <div><b>GMW</b><p>مرجع ثبت و پیگیری گارانتی، اصالت‌سنجی قطعات و خدمات پس از فروش خودرو. این نسخه آزمایشی است و هنوز خدمت واقعی ارائه نمی‌کند.</p></div>
      <nav aria-label="پیوندهای پایانی">
        <a href="${link('/about/')}">درباره GMW</a><a href="${link('/contact/')}">تماس</a><a href="${link('/terms/')}">قوانین</a>
        <a href="${link('/privacy/')}">حریم خصوصی</a><a href="${link('/warranty-guide/')}">راهنمای گارانتی</a>
      </nav>
    </div>
    <p class="fine">GMW در این نسخه عنوان «بیمه» یا «بیمه‌نامه» ارائه نمی‌کند. طرح‌ها پیش از فروش واقعی از نظر حقوقی و مالی بازبینی می‌شوند. © GMW</p>
  </div>
</footer>
${dl()}
${scripts}
</body>
</html>`;
}
