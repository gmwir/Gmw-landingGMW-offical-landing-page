// تعریف صفحات GMW — هر صفحه: مسیر، عنوان، توضیح متا، بدنه
import { SERVICES, icon, field, select, textarea, checkbox, yearSelect, resultBox, demoBadge, esc } from './layout.mjs';

const card = (s, link) => `<a class="card" href="${link('/' + s.slug + '/')}"><span class="ic-wrap">${icon(s.icon)}</span><h3>${s.title}</h3><p>${s.text}</p><span class="more">ورود ${icon('arrow')}</span></a>`;
const pageHead = (h1, lead, extra = '') => `<section class="page-head"><div class="wrap"><h1>${h1}</h1><p class="lead">${lead}</p>${extra}</div></section>`;
const notice = (t, kind = 'warn') => `<div class="notice ${kind}">${t}</div>`;
const submit = (t) => `<button class="btn block" type="submit">${t}</button>`;

const faq = [
  ['آیا GMW بیمه‌نامه ارائه می‌کند؟', 'خیر. در این نسخه عنوان «بیمه» یا «بیمه‌نامه» استفاده نمی‌شود و ماهیت حقوقی طرح‌های پوششی پیش از فروش واقعی بررسی خواهد شد.'],
  ['آیا پرداخت‌ها واقعی هستند؟', 'خیر. پرداخت در این نسخه آزمایشی است و هیچ درگاه یا مبلغ واقعی فعال نیست.'],
  ['اطلاعاتی که ثبت می‌کنم کجا می‌ماند؟', 'در این نسخه فقط در حافظهٔ مرورگر شما ذخیره می‌شود و به هیچ سرور یا پیامکی ارسال نمی‌شود.'],
  ['صندوق شفاف گارانتی پرونده‌های واقعی را نشان می‌دهد؟', 'در این نسخه خیر؛ همهٔ پرونده‌ها با برچسب «نمونه نمایشی» مشخص شده‌اند.']
];

export const pages = [
  /* ================= خانه ================= */
  {
    id: 'home', path: '/', title: 'GMW | گارانتی، اصالت‌سنجی قطعات و خدمات پس از فروش خودرو',
    desc: 'GMW: فعال‌سازی و استعلام گارانتی، اصالت‌سنجی قطعات، طرح پوشش سه‌ساله جلوبندی، خدمات لنت و باشگاه مشتریان خودرو (نسخهٔ آزمایشی).',
    jsonld: [{ '@context': 'https://schema.org', '@type': 'FAQPage', mainEntity: faq.map(([q, a]) => ({ '@type': 'Question', name: q, acceptedAnswer: { '@type': 'Answer', text: a } })) }],
    body: ({ link }) => `
<section class="hero"><div class="wrap">
  <p class="eyebrow">نسخهٔ اولیهٔ آزمایشی</p>
  <h1>گارانتی و خدمات خودرو؛ شفاف و قابل‌پیگیری</h1>
  <p class="lead">قطعه‌تان را فعال‌سازی کنید، اصالتش را بسنجید و مسیر خدمات پس از فروش را قدم‌به‌قدم ببینید.</p>
  <div class="row"><a class="btn" href="${link('/warranty/')}">فعال‌سازی گارانتی</a><a class="btn ghost" href="#services">مشاهدهٔ خدمات</a></div>
</div></section>
<section class="section" id="services"><div class="wrap">
  <h2>هشت خدمت اصلی</h2>
  <div class="cards" role="list">${SERVICES.map((s) => card(s, link)).join('')}</div>
  <p class="swipe-hint">برای دیدن خدمات بیشتر، کارت‌ها را بکشید</p>
</div></section>
<section class="section"><div class="wrap">
  <a class="band dark" href="${link('/brake-service/')}">
    <div><span class="eyebrow amber">خدمت ویژهٔ GMW</span><h2>سه نوبت تعویض لنت در هر سال</h2>
    <p>اجرت تعویض در نوبت‌های مجاز رایگان؛ قیمت لنت و اجرت نصب، شفاف و جداگانه نمایش داده می‌شود.</p></div>
    <span class="band-ic">${icon('brake')}</span>
  </a>
  <a class="band" href="${link('/coverage-plan/')}">
    <div><span class="eyebrow">طرح جدید</span><h2>طرح پوشش سه‌ساله خدمات جلوبندی و عقب‌بندی</h2>
    <p>قطعات موردنظر را خودتان انتخاب کنید و قیمت را لحظه‌ای ببینید.</p></div>
    <span class="band-ic">${icon('layers')}</span>
  </a>
</div></section>
<section class="section alt"><div class="wrap">
  <h2>چرا GMW؟</h2>
  <div class="trust">
    <div><h3>شفافیت</h3><p>شرایط، استثناها و قیمت‌ها پیش از ثبت دیده می‌شوند.</p></div>
    <div><h3>اصالت‌سنجی</h3><p>هر کد اسکرچ فقط یک‌بار قابل ثبت است و سریال تکراری پذیرفته نمی‌شود.</p></div>
    <div><h3>پیگیری</h3><p>هر درخواست کد رهگیری دارد و وضعیتش قابل پیگیری است.</p></div>
  </div>
</div></section>
<section class="section"><div class="wrap narrow">
  <h2>پرسش‌های متداول</h2>
  ${faq.map(([q, a]) => `<details class="faq"><summary>${q}</summary><p>${a}</p></details>`).join('')}
</div></section>`
  },

  /* ================= گارانتی ================= */
  {
    id: 'warranty', path: '/warranty/', title: 'فعال‌سازی و استعلام گارانتی', desc: 'کد اسکرچ قطعه را ثبت کنید، اصالت آن را بسنجید و کد رهگیری فعال‌سازی گارانتی بگیرید.',
    body: ({ link }) => pageHead('فعال‌سازی و استعلام گارانتی', 'اطلاعات قطعه و فاکتور را ثبت کنید؛ پس از ثبت، کد رهگیری و وضعیت فعال‌سازی را می‌بینید.') + `
<section class="section"><div class="wrap grid2">
  <form id="warranty-form" class="panel" novalidate>
    <h2>فرم فعال‌سازی</h2>
    ${field({ name: 'scratchCode', label: 'کد اسکرچ', attrs: 'autocapitalize="characters" dir="ltr" autocomplete="off"', hint: 'هر کد فقط یک‌بار قابل ثبت است.' })}
    ${field({ name: 'serial', label: 'شناسه یا سریال قطعه', attrs: 'dir="ltr" autocomplete="off"' })}
    ${field({ name: 'partName', label: 'نام قطعه' })}
    ${field({ name: 'brand', label: 'برند' })}
    ${textarea({ name: 'specs', label: 'مشخصات قطعه', rows: 2 })}
    ${field({ name: 'vehicleModel', label: 'مدل خودرو', list: 'cars' })}
    ${yearSelect('vehicleYear')}
    ${field({ name: 'purchaseDate', label: 'تاریخ خرید', type: 'date' })}
    ${field({ name: 'buyerName', label: 'نام خریدار' })}
    ${field({ name: 'buyerPhone', label: 'شمارهٔ موبایل خریدار', type: 'tel', placeholder: '۰۹۱۲۳۴۵۶۷۸۹' })}
    ${field({ name: 'seller', label: 'فروشنده' })}
    ${field({ name: 'invoice', label: 'تصویر فاکتور', type: 'file', attrs: 'accept="image/*,application/pdf"', hint: 'در این نسخه فقط نام و حجم فایل ثبت می‌شود؛ ذخیرهٔ فایل در Backend انجام خواهد شد.' })}
    ${submit('ثبت و فعال‌سازی')}${resultBox}
  </form>
  <div>
    <form id="warranty-lookup" class="panel" novalidate>
      <h2>استعلام گارانتی</h2>
      ${field({ name: 'q', label: 'کد رهگیری یا سریال قطعه', attrs: 'dir="ltr" autocomplete="off"' })}
      ${submit('استعلام')}${resultBox}
    </form>
    <details class="panel demo-codes"><summary>کدهای اسکرچ آزمایشی برای تست ${demoBadge}</summary>
      <p class="hint">این کدها فقط برای آزمایش‌اند. هر کد پس از استفاده «مصرف‌شده» می‌شود.</p><ul id="demo-codes" class="codes"></ul></details>
  </div>
</div></section>`
  },

  /* ================= طرح سه‌ساله ================= */
  {
    id: 'coverage', path: '/coverage-plan/', title: 'طرح پوشش سه‌ساله خدمات جلوبندی و عقب‌بندی GMW',
    desc: 'قطعات جلوبندی و عقب‌بندی موردنظر را انتخاب کنید، قیمت را لحظه‌ای ببینید و درخواست طرح پوشش سه‌ساله را ثبت کنید (نسخهٔ آزمایشی).',
    body: ({ link }) => pageHead('طرح پوشش سه‌ساله خدمات جلوبندی و عقب‌بندی GMW', 'قطعات موردنظر را انتخاب کنید؛ قیمت براساس انتخاب شما لحظه‌ای محاسبه می‌شود.') + `
<section class="section"><div class="wrap">
  ${notice('<b>توجه:</b> این طرح بیمه یا بیمه‌نامه نیست. قیمت‌های این صفحه آزمایشی‌اند و شرایط، استثناها، سقف تعهد هر قطعه و تعداد دفعات تعویض پیش از فروش واقعی نهایی می‌شود. هیچ مبلغ واقعی دریافت نمی‌شود.')}
  <ol class="steps" aria-label="مراحل ثبت درخواست">
    <li>انتخاب قطعات</li><li>محاسبهٔ قیمت</li><li>مشخصات مالک و خودرو</li><li>پرداخت آزمایشی</li><li>کد رهگیری</li><li>معرفی استادکار در شهر شما</li><li>معاینهٔ خودرو</li><li>تأیید یا رد با ذکر دلیل</li><li>فعال‌سازی پوشش</li>
  </ol>
  <form id="coverage-form" novalidate>
    <div class="panel"><h2>۱. انتخاب قطعات</h2><div id="parts"><p class="hint">در حال بارگذاری…</p></div><small class="err" data-err="parts" role="alert"></small></div>
    <div class="panel"><h2>۲. مشخصات مالک و خودرو</h2><div class="grid2in">
      ${field({ name: 'name', label: 'نام و نام خانوادگی' })}
      ${field({ name: 'phone', label: 'شمارهٔ موبایل', type: 'tel', placeholder: '۰۹۱۲۳۴۵۶۷۸۹' })}
      ${field({ name: 'city', label: 'شهر', list: 'cities' })}
      ${field({ name: 'address', label: 'آدرس' })}
      ${field({ name: 'model', label: 'مدل خودرو', list: 'cars' })}
      ${yearSelect('year')}
      ${field({ name: 'mileage', label: 'کارکرد (کیلومتر)', type: 'text', attrs: 'inputmode="numeric"' })}
      ${select({ name: 'accident', label: 'سابقهٔ تصادف', options: ['ندارد', 'جزئی', 'شدید یا تعمیر اساسی'] })}
    </div>
    ${textarea({ name: 'repairs', label: 'سابقهٔ تعمیرات جلوبندی و عقب‌بندی', rows: 2 })}
    ${textarea({ name: 'notes', label: 'توضیحات', rows: 2 })}</div>
    <div class="panel"><h2>۳. پرداخت آزمایشی</h2>
      <div class="total-box"><span>مبلغ قابل پرداخت (آزمایشی)</span><b id="total-amount">—</b></div>
      <p class="hint" id="total-note"></p>
      ${checkbox({ name: 'acceptTerms', label: 'می‌دانم این ثبت آزمایشی است و شرایط و استثنای نهایی طرح پس از بازبینی حقوقی اعلام می‌شود.' })}
      <button class="btn block" type="submit">پرداخت آزمایشی و ثبت درخواست</button>${resultBox}
    </div>
  </form>
  <div id="coverage-result"></div>
  <form id="coverage-track" class="panel" novalidate><h2>پیگیری درخواست</h2>
    ${field({ name: 'q', label: 'کد رهگیری', attrs: 'dir="ltr" autocomplete="off"', placeholder: 'GMW-C-XXXXXX' })}
    ${submit('پیگیری')}${resultBox}</form>
</div></section>
<div class="total-bar" id="total-bar" hidden><span><b id="sel-count">۰</b> قطعه</span><b id="total-bar-amount">—</b><a class="btn small" href="#coverage-form">ادامه</a></div>`
  },

  /* ================= لنت ================= */
  {
    id: 'brake', path: '/brake-service/', title: 'خدمات لنت ترمز؛ سه نوبت تعویض در هر سال',
    desc: 'خدمت ویژهٔ لنت GMW: سه نوبت تعویض لنت در هر سال دورهٔ سه‌ساله، اجرت تعویض رایگان در نوبت‌های مجاز و قیمت شفاف لنت (نسخهٔ آزمایشی).',
    body: ({ link }) => `
<section class="hero dark"><div class="wrap">
  <p class="eyebrow amber">خدمت ویژهٔ GMW</p>
  <h1>سه نوبت تعویض لنت در هر سال</h1>
  <p class="lead">در دورهٔ سه‌ساله، هر سال سه نوبت؛ اجرت تعویض در نوبت‌های مجاز رایگان و قیمت لنت جدا و شفاف.</p>
  <div class="slots" aria-label="سهمیهٔ سه‌ساله: سه سال، هر سال سه نوبت">
    ${[1, 2, 3].map((y) => `<div class="year"><span>سال ${['اول', 'دوم', 'سوم'][y - 1]}</span><div>${[1, 2, 3].map(() => `<i>${icon('check')}</i>`).join('')}</div></div>`).join('')}
  </div>
  <p class="fine-light">حداکثر ۹ نوبت در سه سال؛ سهمیهٔ هر سال جداگانه کنترل می‌شود.</p>
  <a class="btn amber" href="#brake-form">ثبت درخواست تعویض</a>
</div></section>
<section class="section"><div class="wrap">
  ${notice('<b>شفافیت:</b> «اجرت تعویض» در نوبت‌های مجاز رایگان است؛ <b>خود لنت رایگان نیست</b> و با قیمت عمده (آزمایشی در این نسخه) عرضه می‌شود. تعهد قطعی منوط به بررسی هزینهٔ تأمین لنت، شرایط مصرف، محدودیت کیلومتر و توان اجرایی است.')}
  <div class="grid2">
    <div class="panel"><h2>قیمت لنت <small class="muted">(جدا از اجرت)</small></h2><div id="brake-prices"></div></div>
    <div class="panel"><h2>اجرت نصب <small class="muted">(جدا از لنت)</small></h2><div id="brake-labor"></div></div>
  </div>
</div></section>
<section class="section alt"><div class="wrap grid2">
  <form id="brake-quota" class="panel" novalidate><h2>سهمیهٔ من</h2>
    ${field({ name: 'phone', label: 'شمارهٔ موبایل عضو', type: 'tel' })}${submit('نمایش سهمیه و سوابق')}${resultBox}</form>
  <form id="brake-form" class="panel" novalidate><h2>درخواست تعویض لنت</h2>
    ${field({ name: 'name', label: 'نام' })}${field({ name: 'phone', label: 'شمارهٔ موبایل عضو', type: 'tel' })}
    ${field({ name: 'city', label: 'شهر', list: 'cities' })}
    ${field({ name: 'model', label: 'مدل خودرو', list: 'cars' })}${yearSelect('year')}
    ${select({ name: 'padClass', label: 'نوع لنت', options: [] })}
    ${select({ name: 'centerId', label: 'مرکز خدماتی', options: [] })}
    ${textarea({ name: 'notes', label: 'توضیحات', rows: 2 })}
    ${submit('ثبت درخواست')}${resultBox}</form>
</div></section>
<section class="section"><div class="wrap"><h2>مراکز خدماتی ${demoBadge}</h2><p class="hint">فهرست نمونه است؛ مراکز واقعی پس از عقد قرارداد اضافه می‌شوند. شهر را در فرم بالا وارد کنید تا نزدیک‌ترین مراکز نمایش داده شوند.</p><div id="centers" class="centers"></div>
  <h2>سوابق تعویض</h2><p class="hint">پس از انجام هر نوبت، تاریخ، نوع لنت، خودرو و مرکز نصب در سوابق عضو ثبت می‌شود و از «سهمیهٔ من» قابل مشاهده است.</p></div></section>`
  },

  /* ================= صندوق شفاف ================= */
  {
    id: 'fund', path: '/transparent-fund/', title: 'صندوق شفاف گارانتی', desc: 'داشبورد نمایشی مسیر رسیدگی به پرونده‌های گارانتی: تاریخ خرید، درخواست خسارت، کارشناسی، نتیجه، مبلغ، پرداخت و مدت رسیدگی (نمونه نمایشی).',
    body: () => pageHead('صندوق شفاف گارانتی', 'مسیر رسیدگی به پرونده‌ها از خرید تا پرداخت، به‌صورت روشن و قابل‌پیگیری.') + `
<section class="section"><div class="wrap">
  ${notice('<b>همهٔ اطلاعات این صفحه نمونهٔ نمایشی است.</b> هیچ‌یک از پرونده‌ها، مبالغ و پرداخت‌ها واقعی نیستند و فقط برای نمایش ساختار داشبورد آمده‌اند.', 'demo')}
  <div class="tiles" id="fund-tiles"></div>
  <div class="field inline"><label for="fund-filter">فیلتر نتیجه</label><select id="fund-filter"><option value="">همه</option><option value="تأیید">تأیید</option><option value="رد">رد</option><option value="در حال بررسی">در حال بررسی</option></select></div>
  <div class="table-wrap"><table class="table" id="fund-table"><thead><tr><th>پرونده</th><th>تاریخ خرید</th><th>درخواست خسارت</th><th>کارشناسی</th><th>نتیجه</th><th>مبلغ خسارت</th><th>پرداخت</th><th>مدت رسیدگی</th></tr></thead><tbody></tbody></table></div>
</div></section>`
  },

  /* ================= باشگاه ================= */
  {
    id: 'club', path: '/club/', title: 'باشگاه مشتریان GMW', desc: 'عضویت با نام و موبایل، ثبت خودرو، اتصال کد گارانتی، مشاهدهٔ سوابق خدمات و پیشنهادها.',
    body: () => pageHead('باشگاه مشتریان', 'با نام و موبایل عضو شوید؛ خودرو و گارانتی‌هایتان را در یک‌جا ببینید.') + `
<section class="section" id="club-guest"><div class="wrap grid2">
  <form id="club-join" class="panel" novalidate><h2>عضویت</h2>
    ${field({ name: 'name', label: 'نام' })}${field({ name: 'phone', label: 'شمارهٔ موبایل', type: 'tel' })}
    ${field({ name: 'vehicleModel', label: 'مدل خودرو', list: 'cars', req: false })}${yearSelectOpt()}
    ${checkbox({ name: 'consentMarketing', label: 'با دریافت پیشنهادها و اطلاع‌رسانی‌های GMW موافقم (اختیاری، هر زمان قابل لغو).' })}
    ${submit('عضویت')}${resultBox}</form>
  <form id="club-login" class="panel" novalidate><h2>ورود اعضا</h2>
    ${field({ name: 'phone', label: 'شمارهٔ موبایل', type: 'tel' })}${submit('ورود')}${resultBox}
    <p class="hint">در نسخهٔ آزمایشی ورود فقط با شمارهٔ موبایل است. در نسخهٔ واقعی تأیید با کد پیامکی انجام می‌شود.</p></form>
</div></section>
<section class="section" id="club-member" hidden><div class="wrap">
  <div class="row between"><h2 id="m-name">عضو GMW</h2><button class="btn ghost small" id="m-logout" type="button">خروج</button></div>
  <div class="grid2">
    <div class="panel"><h3>خودروها</h3><ul id="m-vehicles" class="plain"></ul>
      <form id="club-vehicle" novalidate>${field({ name: 'vehicleModel', label: 'مدل خودرو', list: 'cars' })}${yearSelect('vehicleYear')}${submit('افزودن خودرو')}${resultBox}</form></div>
    <div class="panel"><h3>اتصال کد گارانتی</h3>
      <form id="club-link" novalidate>${field({ name: 'code', label: 'کد رهگیری یا سریال', attrs: 'dir="ltr"' })}${submit('اتصال')}${resultBox}</form>
      <ul id="m-linked" class="plain"></ul></div>
    <div class="panel"><h3>سوابق خدمات</h3><div id="m-history"></div></div>
    <div class="panel"><h3>سهمیهٔ لنت</h3><div id="m-quota"></div></div>
    <div class="panel"><h3>پیشنهادها و تخفیف‌ها ${demoBadge}</h3><ul id="m-offers" class="plain"><li>پیشنهاد نمونه: یادآوری سرویس دوره‌ای <small class="muted">(نمایشی)</small></li><li>پیشنهاد نمونه: بازدید رایگان جلوبندی <small class="muted">(نمایشی؛ تعهد واقعی نیست)</small></li></ul></div>
    <div class="panel"><h3>درخواست خدمت</h3>
      <form id="club-service" novalidate>${select({ name: 'type', label: 'نوع خدمت', options: ['بررسی گارانتی', 'تعویض لنت', 'بازدید جلوبندی', 'سایر'] })}${textarea({ name: 'message', label: 'توضیحات', req: true, rows: 3 })}${submit('ثبت درخواست')}${resultBox}</form></div>
  </div>
</div></section>`
  },

  /* ================= سبد اقتصادی ================= */
  {
    id: 'basket', path: '/economy-basket/', title: 'سبد اقتصادی لوازم مصرفی خودرو', desc: 'ثبت علاقه‌مندی به سبد اقتصادی لنت، روغن، فیلتر و شمع؛ پس از آماده‌شدن سبد مناسب خودروی شما اطلاع می‌دهیم.',
    body: () => pageHead('سبد اقتصادی لوازم مصرفی', 'ثبت علاقه‌مندی؛ هنوز فروش یا قیمت قطعی اعلام نشده است.') + `
<section class="section"><div class="wrap narrow">
  ${notice('در این مرحله فقط علاقه‌مندی ثبت می‌شود. پس از آماده‌شدن سبد مناسب خودروی شما، با رضایت‌تان اطلاع می‌دهیم.', 'info')}
  <form id="basket-form" class="panel" novalidate>
    <fieldset class="chips"><legend>دسته‌ها</legend>
      ${['لنت', 'روغن', 'فیلترها', 'شمع', 'سایر قطعات مصرفی'].map((c) => `<label class="chip"><input type="checkbox" name="categories" value="${c}"><span>${c}</span></label>`).join('')}
      <small class="err" data-err="categories" role="alert"></small></fieldset>
    ${field({ name: 'model', label: 'مدل خودرو', list: 'cars' })}${yearSelect('year')}
    ${field({ name: 'phone', label: 'شمارهٔ موبایل', type: 'tel' })}
    ${checkbox({ name: 'consentNotify', label: 'رضایت می‌دهم هنگام آماده‌شدن سبد، به من اطلاع داده شود.' })}
    ${submit('ثبت علاقه‌مندی')}${resultBox}</form>
</div></section>`
  },

  /* ================= لاستیک ================= */
  {
    id: 'tire', path: '/tire/', title: 'ثبت‌نام لاستیک حواله‌ای', desc: 'درخواست خود را برای لاستیک حواله‌ای ثبت کنید تا در صورت موجودشدن یا فراهم‌شدن امکان ثبت‌نام اطلاع بدهیم.',
    body: () => pageHead('ثبت‌نام لاستیک حواله‌ای', 'درخواست ثبت می‌شود و در صورت فراهم‌شدن امکان، خبردار می‌شوید.') + `
<section class="section"><div class="wrap narrow">
  ${notice('<b>بدون وعدهٔ قطعی:</b> تا زمانی که موجودی یا سهمیه قطعی نشده، هیچ تعهدی برای فروش، قیمت یا تحویل وجود ندارد.')}
  <form id="tire-form" class="panel" novalidate>
    ${field({ name: 'name', label: 'نام' })}${field({ name: 'phone', label: 'شمارهٔ موبایل', type: 'tel' })}${field({ name: 'city', label: 'شهر', list: 'cities' })}
    ${field({ name: 'model', label: 'مدل خودرو', list: 'cars' })}${yearSelect('year')}
    ${field({ name: 'size', label: 'سایز لاستیک', placeholder: '205/60R15', attrs: 'dir="ltr"' })}
    ${field({ name: 'brand', label: 'برند موردنظر', req: false })}
    ${checkbox({ name: 'consentNotify', label: 'رضایت می‌دهم در صورت موجودشدن یا امکان ثبت‌نام، به من اطلاع داده شود.' })}
    ${submit('ثبت درخواست')}${resultBox}</form>
</div></section>`
  },

  /* ================= مهندس خودرو ================= */
  {
    id: 'ai', path: '/ai-engineer/', ai: true, title: 'مهندس خودرو مبتنی بر هوش مصنوعی', desc: 'علائم خودرو را شرح دهید و علت‌های احتمالی، قطعات نیازمند بررسی، میزان فوریت و سؤالات تکمیلی را ببینید. تشخیص قطعی نیست.',
    body: () => pageHead('مهندس خودرو', 'مشکل خودرو را بنویسید؛ راهنمای اولیه و میزان فوریت را ببینید.') + `
<section class="section"><div class="wrap narrow">
  ${notice('این ابزار تشخیص قطعی نمی‌دهد. تشخیص نهایی فقط با معاینهٔ حضوری ممکن است. در این نسخه، تحلیل با قواعد محلی انجام می‌شود و هیچ API پولی فعال نیست.', 'info')}
  <form id="ai-form" class="panel" novalidate>
    ${field({ name: 'model', label: 'مدل خودرو', list: 'cars', req: false })}
    ${textarea({ name: 'symptoms', label: 'علائم', req: true, rows: 5, hint: 'مثال: هنگام ترمز صدای جیرجیر می‌آید و فرمان می‌لرزد.' })}
    ${submit('بررسی علائم')}</form>
  <div id="ai-result" aria-live="polite"></div>
</div></section>`
  },

  /* ================= بیمه ================= */
  {
    id: 'insurance', path: '/insurance-discount/', title: 'تخفیف بیمه ویژه اعضا', desc: 'ثبت درخواست اطلاع از تخفیف بیمه ویژهٔ اعضا. در حال حاضر قراردادی با شرکت بیمه وجود ندارد و تخفیفی تضمین نمی‌شود.',
    body: () => pageHead('تخفیف بیمه ویژه اعضا', 'درخواست خود را ثبت کنید تا در صورت برقراری همکاری رسمی، اطلاع دهیم.') + `
<section class="section"><div class="wrap narrow">
  ${notice('<b>وضعیت فعلی:</b> هنوز قرارداد همکاری با هیچ شرکت بیمه‌ای وجود ندارد؛ بنابراین هیچ تخفیف یا همکاری قطعی اعلام نمی‌شود.')}
  <form id="insurance-form" class="panel" novalidate>
    ${field({ name: 'name', label: 'نام' })}${field({ name: 'phone', label: 'شمارهٔ موبایل', type: 'tel' })}
    ${field({ name: 'model', label: 'مدل خودرو', list: 'cars' })}
    ${field({ name: 'insurer', label: 'بیمه‌گر فعلی', hint: 'اگر بیمه‌نامه ندارید بنویسید «ندارم».' })}
    ${field({ name: 'expiry', label: 'تاریخ پایان بیمه‌نامهٔ فعلی', req: false, type: 'date' })}
    ${checkbox({ name: 'consentNotify', label: 'رضایت می‌دهم در صورت برقراری همکاری، به من اطلاع داده شود.' })}
    ${submit('ثبت درخواست')}${resultBox}</form>
</div></section>`
  },

  /* ================= تماس ================= */
  {
    id: 'contact', path: '/contact/', title: 'ارتباط با ما', desc: 'پیام یا پیشنهاد خود را برای GMW بفرستید؛ نام، موبایل، موضوع و متن پیام را وارد کنید.',
    body: () => pageHead('ارتباط با ما', 'پیام شما با کد رهگیری ثبت می‌شود و پیگیری می‌کنیم.') + `
<section class="section"><div class="wrap grid2">
  <form id="contact-form" class="panel" novalidate>
    ${field({ name: 'name', label: 'نام' })}${field({ name: 'phone', label: 'شمارهٔ موبایل', type: 'tel' })}
    ${select({ name: 'subject', label: 'موضوع', options: ['پشتیبانی گارانتی', 'طرح سه‌ساله', 'خدمات لنت', 'همکاری فروشندگان و مراکز خدماتی', 'پیشنهاد و انتقاد', 'سایر'] })}
    ${textarea({ name: 'message', label: 'متن پیام', req: true, rows: 5 })}${submit('ارسال پیام')}${resultBox}</form>
  <div class="panel"><h2>راه‌های ارتباطی</h2>
    <p class="hint">اطلاعات تماس رسمی (شماره، نشانی، ساعت پاسخ‌گویی) پس از تأیید مدیریت در همین بخش درج می‌شود.</p>
    <ul class="plain"><li>پیام‌های ثبت‌شده در پنل مدیریت دیده می‌شوند.</li><li>در نسخهٔ آزمایشی پیامک یا ایمیل واقعی ارسال نمی‌شود.</li></ul></div>
</div></section>`
  },

  /* ================= درباره و حقوقی ================= */
  {
    id: 'about', path: '/about/', title: 'درباره GMW', desc: 'GMW قرار است مرجعی معتبر برای گارانتی، اصالت‌سنجی قطعات، خدمات لنت و باشگاه مشتریان خودرو باشد.',
    body: () => pageHead('درباره GMW', 'هدف GMW ساخت اکوسیستمی مشتری‌محور برای خدمات و قطعات خودرو است.') + `
<section class="section"><div class="wrap narrow prose">
  <p>GMW با تمرکز بر گارانتی، اصالت‌سنجی قطعات، خدمات لنت و خدمات پس از فروش شکل می‌گیرد. اصول ما: شفافیت شرایط، قابلیت پیگیری و وعده ندادنِ چیزی که هنوز تأمین‌شدنی نیست.</p>
  <p>این سایت نسخهٔ اولیهٔ آزمایشی است. هیچ‌یک از خدمات پولی هنوز فعال نشده و پیش از فروش واقعی، بازبینی حقوقی و مالی انجام می‌شود.</p>
</div></section>`
  },
  {
    id: 'terms', path: '/terms/', title: 'قوانین و شرایط استفاده', desc: 'پیش‌نویس قوانین استفاده از GMW؛ نسخهٔ آزمایشی و در انتظار بازبینی حقوقی.',
    body: () => pageHead('قوانین و شرایط استفاده', 'پیش‌نویس — پیش از انتشار واقعی باید توسط مشاور حقوقی نهایی شود.') + `
<section class="section"><div class="wrap narrow prose">
  <h2>۱. ماهیت نسخهٔ فعلی</h2><p>این وب‌سایت آزمایشی است. پرداخت‌ها آزمایشی‌اند و اطلاعات، فقط در مرورگر شما نگهداری می‌شود.</p>
  <h2>۲. عدم ارائهٔ بیمه</h2><p>GMW در این نسخه عنوان بیمه یا بیمه‌نامه ارائه نمی‌کند و ماهیت حقوقی طرح پوشش پیش از فروش واقعی بررسی می‌شود.</p>
  <h2>۳. طرح پوشش سه‌ساله</h2><p>شرایط، استثناها، سقف تعهد هر قطعه، تعداد دفعات تعویض و موارد خرابی، استهلاک، تصادف، دستکاری و تحویل قطعهٔ معیوب پیش از فروش نهایی می‌شود.</p>
  <h2>۴. خدمت لنت</h2><p>اجرت تعویض در نوبت‌های مجاز رایگان است؛ لنت جداگانه قیمت‌گذاری می‌شود. سهمیهٔ هر سال جداگانه کنترل می‌شود و تعهد قطعی پس از بررسی هزینه، شرایط مصرف و محدودیت کیلومتر اعلام می‌شود.</p>
  <h2>۵. لاستیک و بیمه</h2><p>ثبت درخواست لاستیک یا تخفیف بیمه، وعدهٔ فروش، تحویل یا تخفیف نیست.</p>
</div></section>`
  },
  {
    id: 'privacy', path: '/privacy/', title: 'حریم خصوصی', desc: 'پیش‌نویس سیاست حریم خصوصی GMW: چه اطلاعاتی ثبت می‌شود، چرا و چگونه رضایت شما رعایت می‌شود.',
    body: () => pageHead('حریم خصوصی', 'پیش‌نویس — در انتظار بازبینی حقوقی.') + `
<section class="section"><div class="wrap narrow prose">
  <h2>داده‌های ثبت‌شده</h2><p>نام، شمارهٔ موبایل، شهر، مشخصات خودرو و اطلاعات فرم‌هایی که خودتان تکمیل می‌کنید.</p>
  <h2>محل نگهداری در نسخهٔ آزمایشی</h2><p>فقط در حافظهٔ همین مرورگر. هیچ داده‌ای به سرور، پیامک یا شخص ثالث ارسال نمی‌شود.</p>
  <h2>پیام‌های تبلیغاتی و اطلاع‌رسانی</h2><p>فقط با رضایت صریح شما و با امکان لغو. رضایت هر فرم جداگانه ثبت می‌شود.</p>
  <h2>حذف داده</h2><p>می‌توانید داده‌های مرورگر را پاک کنید. در نسخهٔ واقعی، درخواست حذف از طریق «ارتباط با ما» پیگیری می‌شود.</p>
</div></section>`
  },
  {
    id: 'guide', path: '/warranty-guide/', title: 'راهنمای گارانتی', desc: 'راهنمای مراحل فعال‌سازی گارانتی، استعلام، یک‌بارمصرف‌بودن کد اسکرچ و پیگیری درخواست‌ها در GMW.',
    body: ({ link }) => pageHead('راهنمای گارانتی', 'از فعال‌سازی تا پیگیری، در چند قدم.') + `
<section class="section"><div class="wrap narrow prose">
  <ol>
    <li>کد اسکرچ را از روی بستهٔ قطعه بخوانید. هر کد فقط یک‌بار قابل ثبت است.</li>
    <li>در <a href="${link('/warranty/')}">صفحهٔ فعال‌سازی</a> مشخصات قطعه، خودرو، خریدار، فروشنده و تصویر فاکتور را ثبت کنید.</li>
    <li>کد رهگیری و وضعیت را یادداشت کنید؛ وضعیت پس از بررسی فاکتور به‌روز می‌شود.</li>
    <li>برای استعلام، کد رهگیری یا سریال را وارد کنید.</li>
    <li>سریال تکراری یا کد مصرف‌شده پذیرفته نمی‌شود.</li>
  </ol>
  <p>شرایط و استثنای دقیق هر گارانتی پیش از ارائهٔ واقعی تکمیل و اعلام خواهد شد.</p>
</div></section>`
  },

  /* ================= پنل مدیریت ================= */
  {
    id: 'admin', path: '/admin/', admin: true, noindex: true, title: 'پنل مدیریت (نمونه)', desc: 'پنل مدیریت آزمایشی GMW.',
    body: () => `<section class="section"><div class="wrap"><h1>پنل مدیریت</h1>
  ${notice('نمونهٔ آزمایشی: بدون احراز هویت واقعی. نقش‌ها برای نمایش سطح دسترسی‌اند و در Backend واقعی با ورود امن و کنترل سمت سرور اجرا می‌شوند.', 'info')}
  <div id="admin-root"><p class="hint">در حال بارگذاری…</p></div></div></section>`
  },

  /* ================= ۴۰۴ ================= */
  {
    id: 'notfound', path: '/404.html', file: '404.html', noindex: true, title: 'صفحه پیدا نشد', desc: 'صفحهٔ موردنظر پیدا نشد.',
    body: ({ link }) => pageHead('صفحه پیدا نشد', 'آدرس را بررسی کنید یا به صفحهٔ اصلی برگردید.') + `<section class="section"><div class="wrap"><a class="btn" href="${link('/')}">صفحهٔ اصلی</a></div></section>`
  }
];

function yearSelectOpt() {
  const opts = []; for (let y = 1405; y >= 1380; y--) opts.push([String(y), String(y).replace(/\d/g, (d) => '۰۱۲۳۴۵۶۷۸۹'[d])]);
  return select({ name: 'vehicleYear', label: 'سال ساخت (اختیاری)', options: opts, req: false });
}
