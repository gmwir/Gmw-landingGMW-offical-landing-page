import test from 'node:test';
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
const C = require('../src/assets/js/core.js');
const AI = require('../src/assets/js/ai-adapter.js');

const NOW = new Date('2026-11-01T10:00:00Z');
const addDays = (d, n) => new Date(new Date(d).getTime() + n * 86400000);
const wInput = (o = {}) => Object.assign({ scratchCode: 'gmw-demo-1001', serial: 'SN-001', partName: 'کمک‌فنر جلو', brand: 'برند آزمایشی', specs: '', vehicleModel: 'پژو ۲۰۶', vehicleYear: '1398',
  purchaseDate: '2026-10-20', buyerName: 'علی رضایی', buyerPhone: '۰۹۱۲۳۴۵۶۷۸۹', seller: 'فروشنده نمونه', invoice: { name: 'f.jpg', size: 1000 } }, o);
const owner = (o = {}) => Object.assign({ name: 'سارا', phone: '09121112233', city: 'تهران', address: 'آدرس', model: 'دنا', year: '1400', mileage: '۴۵۰۰۰', accident: 'ندارد' }, o);

test('اعداد فارسی و شمارهٔ موبایل نرمال می‌شوند', () => {
  assert.equal(C.normalizeDigits('۰۹۱۲٣'), '09123');
  assert.equal(C.normalizePhone('+98 912 123 4567'), '09121234567');
  assert.equal(C.normalizePhone('۰۹۱۲-۱۲۳-۴۵۶۷'), '09121234567');
  assert.ok(C.isValidMobile('۰۹۳۵۱۲۳۴۵۶۷'));
  assert.ok(!C.isValidMobile('0212345678'));
  assert.ok(!C.isValidMobile('0912345'));
});

test('گارانتی: ثبت موفق، کد یک‌بارمصرف و جلوگیری از سریال تکراری', () => {
  const s = C.defaultState();
  const r1 = C.registerWarranty(s, wInput(), NOW);
  assert.ok(r1.ok); assert.match(r1.record.trackingCode, /^GMW-W-[A-Z0-9]{6}$/);
  assert.equal(r1.record.status, 'pending_review');
  assert.equal(s.scratchCodes[0].status, 'used');
  const r2 = C.registerWarranty(s, wInput({ serial: 'SN-002' }), NOW);               // همان کد
  assert.ok(!r2.ok); assert.match(r2.errors.scratchCode, /قبلاً استفاده/);
  const r3 = C.registerWarranty(s, wInput({ scratchCode: 'GMW-DEMO-1002', serial: 'sn 001' }), NOW); // سریال تکراری (حروف/فاصله متفاوت)
  assert.ok(!r3.ok); assert.match(r3.errors.serial, /قبلاً ثبت/);
  assert.equal(s.scratchCodes[1].status, 'unused', 'کد نباید با خطای سریال مصرف شود');
  assert.equal(s.warranties.length, 1);
});

test('گارانتی: اعتبارسنجی ورودی‌ها', () => {
  const s = C.defaultState();
  assert.equal(C.registerWarranty(s, wInput({ scratchCode: 'NOPE-1' }), NOW).errors.scratchCode, 'این کد در سامانه یافت نشد. کد را دوباره بررسی کنید.');
  assert.ok(C.registerWarranty(s, wInput({ buyerPhone: '123' }), NOW).errors.buyerPhone);
  assert.ok(C.registerWarranty(s, wInput({ purchaseDate: '2027-05-01' }), NOW).errors.purchaseDate);
  assert.ok(C.registerWarranty(s, wInput({ invoice: null }), NOW).errors.invoice);
  assert.ok(C.registerWarranty(s, wInput({ vehicleYear: '' }), NOW).errors.vehicleYear);
  assert.equal(s.warranties.length, 0);
});

test('گارانتی: استعلام با کد رهگیری یا سریال و بدون نشت اطلاعات شخصی', () => {
  const s = C.defaultState(); const r = C.registerWarranty(s, wInput(), NOW);
  const a = C.lookupWarranty(s, r.record.trackingCode.toLowerCase()), b = C.lookupWarranty(s, 'sn-001');
  assert.equal(a.partName, 'کمک‌فنر جلو'); assert.equal(b.trackingCode, a.trackingCode);
  assert.equal(a.buyerPhone, undefined); assert.equal(a.buyerName, undefined);
  assert.equal(C.lookupWarranty(s, 'GMW-W-ZZZZZZ'), null);
});

test('قیمت طرح سه‌ساله: جمع، ضریب، حداقل، سقف و قطعهٔ غیرفعال', () => {
  const s = C.defaultState();
  assert.equal(s.settings.coverage.cap, null, 'سقف ۲٬۳۴۵٬۰۰۰ نباید پیش‌فرض قطعی باشد');
  assert.equal(s.settings.coverage.years, 3);
  const p = C.calcCoveragePrice(s, ['p01', 'p02']); assert.equal(p.total, 1100000);
  s.settings.coverage.multiplier = 1.5; assert.equal(C.calcCoveragePrice(s, ['p01', 'p02']).total, 1650000);
  s.settings.coverage.cap = 1000000; const c = C.calcCoveragePrice(s, ['p01', 'p02']); assert.equal(c.total, 1000000); assert.ok(c.capApplied);
  s.settings.coverage.cap = null; s.settings.coverage.minTotal = 900000; assert.equal(C.calcCoveragePrice(s, ['p08']).total, 900000);
  s.parts.find((x) => x.id === 'p01').active = false; assert.equal(C.calcCoveragePrice(s, ['p01']).items.length, 0);
  assert.equal(s.parts.length, 19);
});

test('طرح سه‌ساله: ثبت، گردش کامل تا فعال‌سازی و ایجاد عضویت لنت', () => {
  const s = C.defaultState();
  const bad = C.createCoverageRequest(s, { parts: [], owner: owner(), acceptTerms: true }, NOW); assert.ok(bad.errors.parts);
  assert.ok(C.createCoverageRequest(s, { parts: ['p01'], owner: owner(), acceptTerms: false }, NOW).errors.acceptTerms);
  const r = C.createCoverageRequest(s, { parts: ['p01', 'p07'], owner: owner(), acceptTerms: true }, NOW);
  assert.ok(r.ok); assert.match(r.record.trackingCode, /^GMW-C-/); assert.equal(r.payment.kind, 'demo'); assert.equal(r.record.total, 720000);
  const id = r.record.id;
  assert.ok(!C.advanceCoverage(s, id, 'approve', {}, 'a', NOW).ok, 'تأیید پیش از معاینه ممنوع');
  assert.ok(!C.advanceCoverage(s, id, 'assign', {}, 'a', NOW).ok, 'بدون انتخاب استادکار ممنوع');
  assert.ok(C.advanceCoverage(s, id, 'assign', { technicianId: 't1' }, 'a', NOW).ok);
  assert.ok(C.advanceCoverage(s, id, 'inspect', { notes: 'سالم' }, 'a', NOW).ok);
  assert.ok(C.advanceCoverage(s, id, 'approve', {}, 'a', NOW).ok);
  assert.equal(s.brakeEnrollments.length, 0);
  assert.ok(C.advanceCoverage(s, id, 'activate', {}, 'a', NOW).ok);
  const rec = s.coverageRequests[0]; assert.equal(rec.status, 'active');
  assert.equal(new Date(rec.endDate).getUTCFullYear() - new Date(rec.startDate).getUTCFullYear(), 3);
  assert.equal(s.brakeEnrollments[0].source, 'coverage');
  assert.ok(s.audit.length >= 5);
});

test('طرح سه‌ساله: رد نیازمند دلیل است و بازپرداخت کامل ایجاد می‌کند', () => {
  const s = C.defaultState();
  const r = C.createCoverageRequest(s, { parts: ['p10'], owner: owner(), acceptTerms: true }, NOW), id = r.record.id;
  assert.ok(!C.advanceCoverage(s, id, 'reject', { reason: '  ' }, 'a', NOW).ok);
  assert.ok(C.advanceCoverage(s, id, 'reject', { reason: 'قطعه قبلاً تصادفی است' }, 'a', NOW).ok);
  assert.equal(s.refunds.length, 1); assert.equal(s.refunds[0].amount, 900000); assert.equal(s.refunds[0].amount, s.payments[0].amount);
  assert.equal(s.payments[0].status, 'refund_pending');
  assert.ok(!C.advanceCoverage(s, id, 'activate', {}, 'a', NOW).ok, 'درخواست ردشده فعال نمی‌شود');
  assert.ok(C.markRefunded(s, s.refunds[0].id, 'fin', NOW).ok);
  assert.equal(s.payments[0].status, 'refunded'); assert.ok(!C.markRefunded(s, s.refunds[0].id, 'fin', NOW).ok, 'بازپرداخت دوباره ممنوع');
});

const bInput = (o = {}) => Object.assign({ name: 'رضا', phone: '09120000001', city: 'تهران', model: 'سمند', year: '1395', padClass: 'c1', centerId: 'k1' }, o);

test('لنت: سه نوبت در هر سال، نوبت چهارم رد می‌شود و سال بعد سهمیه جدید دارد', () => {
  const s = C.defaultState();
  assert.equal(C.createBrakeRequest(s, bInput(), NOW).code, 'NOT_ENROLLED');
  C.joinClub(s, { name: 'رضا', phone: '09120000001' }, NOW);
  for (let i = 1; i <= 3; i++) { const r = C.createBrakeRequest(s, bInput(), addDays(NOW, i)); assert.ok(r.ok, 'نوبت ' + i); assert.equal(r.record.planYear, 1); assert.equal(r.record.laborFee, 0); assert.equal(r.record.padPrice, 280000); }
  const r4 = C.createBrakeRequest(s, bInput(), addDays(NOW, 10)); assert.equal(r4.code, 'QUOTA_EXHAUSTED');
  const y2 = C.createBrakeRequest(s, bInput(), addDays(NOW, 400)); assert.ok(y2.ok); assert.equal(y2.record.planYear, 2);
  const st = C.brakeQuotaStatus(s, '09120000001', addDays(NOW, 400));
  assert.deepEqual(st.table.map((t) => t.used), [3, 1, 0]); assert.deepEqual(st.table.map((t) => t.quota), [3, 3, 3]);
  assert.equal(C.createBrakeRequest(s, bInput(), addDays(NOW, 365 * 3 + 5)).code, 'EXPIRED');
});

test('لنت: سهمیهٔ هر سال جداگانه قابل تنظیم است و بازنویسی فردی کار می‌کند', () => {
  const s = C.defaultState(); C.joinClub(s, { name: 'رضا', phone: '09120000001' }, NOW);
  s.settings.brake.quotas[1] = 1;
  assert.ok(C.createBrakeRequest(s, bInput(), NOW).ok);
  assert.equal(C.createBrakeRequest(s, bInput(), NOW).code, 'QUOTA_EXHAUSTED');
  s.brakeEnrollments[0].quotaOverrides[1] = 2;
  assert.ok(C.createBrakeRequest(s, bInput(), NOW).ok);
  assert.equal(s.settings.brake.quotas[2], 3, 'سهمیهٔ سال دوم دست‌نخورده است');
});

test('لنت: ثبت انجام تعویض سابقه می‌سازد و شمارهٔ نوبت را می‌شمارد', () => {
  const s = C.defaultState(); C.joinClub(s, { name: 'رضا', phone: '09120000001' }, NOW);
  const a = C.createBrakeRequest(s, bInput(), NOW).record, b = C.createBrakeRequest(s, bInput(), NOW).record;
  const h1 = C.completeBrakeRequest(s, a.id, 'ops', NOW), h2 = C.completeBrakeRequest(s, b.id, 'ops', NOW);
  assert.equal(h1.history.seq, 1); assert.equal(h2.history.seq, 2);
  assert.ok(!C.completeBrakeRequest(s, a.id, 'ops', NOW).ok);
  const h = s.brakeHistory[0]; assert.ok(h.padLabel && h.vehicle && h.centerName && h.date);
});

test('باشگاه: عضویت، رضایت تبلیغاتی و اتصال کد گارانتی فقط برای مالک همان شماره', () => {
  const s = C.defaultState();
  assert.ok(C.joinClub(s, { name: '', phone: '1' }, NOW).errors.name);
  const j = C.joinClub(s, { name: 'علی', phone: '۰۹۱۲۳۴۵۶۷۸۹', consentMarketing: false }, NOW);
  assert.ok(j.ok && j.created); assert.equal(j.member.consentMarketing, false); assert.equal(j.member.consentAt, '');
  const w = C.registerWarranty(s, wInput(), NOW).record;
  assert.ok(C.linkWarrantyToMember(s, '09123456789', w.trackingCode).ok);
  assert.ok(!C.linkWarrantyToMember(s, '09123456789', w.trackingCode).ok, 'اتصال تکراری');
  C.joinClub(s, { name: 'دیگری', phone: '09350000000' }, NOW);
  assert.match(C.linkWarrantyToMember(s, '09350000000', w.trackingCode).error, /شمارهٔ?.*دیگری|موبایل دیگری/);
  assert.equal(s.clubMembers.length, 2);
});

test('فرم‌های ساده: لاستیک، سبد، بیمه، تماس؛ رضایت الزامی', () => {
  const s = C.defaultState();
  const t = { name: 'م', phone: '09121234567', city: 'قم', model: 'تیبا', year: '1399', size: '۱۹۵/۶۰R۱۴', brand: '', consentNotify: true };
  assert.ok(!C.addSimple(s, 'tire', Object.assign({}, t, { consentNotify: false }), NOW).ok);
  assert.ok(!C.addSimple(s, 'tire', Object.assign({}, t, { size: 'abc' }), NOW).ok);
  const ok = C.addSimple(s, 'tire', t, NOW); assert.ok(ok.ok); assert.equal(ok.record.size, '195/60R14'); assert.equal(ok.record.status, 'registered_interest');
  assert.ok(!C.addSimple(s, 'basket', { phone: '09121234567', model: 'x', categories: [], consentNotify: true }, NOW).ok);
  assert.ok(C.addSimple(s, 'basket', { phone: '09121234567', model: 'x', categories: ['لنت'], consentNotify: true }, NOW).ok);
  assert.ok(!C.addSimple(s, 'insurance', { name: 'a', phone: '09121234567', model: 'x', insurer: 'ندارم', consentNotify: false }, NOW).ok);
  const ins = C.addSimple(s, 'insurance', { name: 'a', phone: '09121234567', model: 'x', insurer: 'ندارم', consentNotify: true }, NOW);
  assert.equal(ins.record.status, 'registered_interest');
  assert.ok(!C.addSimple(s, 'contact', { name: 'a', phone: '09121234567', subject: 'سایر', message: 'کوتاه' }, NOW).ok);
  assert.ok(C.addSimple(s, 'contact', { name: 'a', phone: '09121234567', subject: 'سایر', message: 'پیام کافی و معتبر' }, NOW).ok);
  const codes = [...s.tireRequests, ...s.basketInterests, ...s.insuranceRequests, ...s.contacts].map((r) => r.trackingCode);
  assert.equal(new Set(codes).size, codes.length, 'کدهای رهگیری یکتا');
});

test('داده‌های نمونهٔ صندوق شفاف همگی با demo علامت‌گذاری شده‌اند', () => {
  const s = C.defaultState(); assert.ok(s.claims.length >= 5); assert.ok(s.claims.every((c) => c.demo === true && c.id.startsWith('نمونه')));
  assert.ok(s.centers.every((c) => c.demo) && s.technicians.every((t) => t.demo));
});

test('مهندس خودرو: قواعد محلی، فوریت و سلب مسئولیت', async () => {
  const a = await AI.diagnose('هنگام ترمز صدای جیرجیر میاد و فرمان می‌لرزه');
  assert.ok(a.matched); assert.ok(a.causes.length && a.parts.length && a.questions.length); assert.equal(a.urgency, 'high');
  assert.match(a.disclaimer, /تشخیص قطعی نیست/);
  const b = await AI.diagnose('پدال ترمز نرم شده و ترمز نمی‌گیره'); assert.equal(b.urgency, 'critical'); assert.match(b.visitAdvice, /متوقف/);
  const c = await AI.diagnose('یه حس عجیب دارم'); assert.equal(c.matched, false); assert.ok(c.questions.length);
  const d = await AI.diagnose('صدای تق تق از جلو موقع دست‌انداز'); assert.equal(d.urgency, 'medium');
  assert.equal(AI.setProvider('remote-llm'), 'local-rules', 'اتصال API پولی غیرفعال است');
  await assert.rejects(AI.providers['remote-llm'].diagnose('x'));
});
