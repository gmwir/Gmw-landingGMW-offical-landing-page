import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const SITE = path.join(ROOT, 'site'), OFF = path.join(ROOT, 'site-offline');
const read = (d, f) => fs.readFileSync(path.join(d, f), 'utf8');
function htmlFiles(dir, acc = []) { for (const e of fs.readdirSync(dir, { withFileTypes: true })) { const p = path.join(dir, e.name); if (e.isDirectory()) htmlFiles(p, acc); else if (p.endsWith('.html')) acc.push(p); } return acc; }
const pages = htmlFiles(SITE);

test('همهٔ صفحات: lang=fa، dir=rtl، یک h1، عنوان، توضیح و viewport', () => {
  assert.ok(pages.length >= 17);
  for (const f of pages) {
    const h = fs.readFileSync(f, 'utf8'), n = path.relative(SITE, f);
    assert.match(h, /<html lang="fa" dir="rtl">/, n);
    assert.equal((h.match(/<h1[ >]/g) || []).length, 1, n + ' باید دقیقاً یک h1 داشته باشد');
    assert.match(h, /<title>[^<]{5,}<\/title>/, n);
    assert.match(h, /<meta name="description" content="[^"]{20,}"/, n);
    assert.match(h, /name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover"/, n);
    assert.match(h, /<link rel="canonical" href="https?:\/\/[^"]+"/, n);
  }
});

test('ساختار هدینگ: پرش از h1 به h3 نداریم', () => {
  for (const f of pages) {
    const hs = [...fs.readFileSync(f, 'utf8').matchAll(/<h([1-6])[ >]/g)].map((m) => +m[1]); let prev = 0;
    for (const l of hs) { assert.ok(l <= prev + 1, `${path.relative(SITE, f)}: h${prev}→h${l}`); prev = Math.max(prev, l); }
  }
});

test('صفحهٔ اصلی: هشت کارت خدمت به ترتیب درخواستی، پیش از سایر بخش‌ها', () => {
  const h = read(SITE, 'index.html');
  const titles = [...h.matchAll(/<a class="card"[^>]*><span class="ic-wrap">.*?<\/span><h3>(.*?)<\/h3>/g)].map((m) => m[1]);
  assert.deepEqual(titles, ['فعال‌سازی و استعلام گارانتی', 'صندوق شفاف گارانتی', 'باشگاه مشتریان', 'سبد اقتصادی لوازم مصرفی خودرو', 'ثبت‌نام لاستیک حواله‌ای', 'مهندس خودرو مبتنی بر هوش مصنوعی', 'تخفیف بیمه ویژه اعضا', 'ارتباط با ما']);
  assert.ok(h.indexOf('id="services"') < h.indexOf('class="band dark"'));
  assert.match(h, /id="login-btn"/); assert.match(h, /ورود \/ عضویت/);
});

test('فوتر: درباره، تماس، قوانین، حریم خصوصی، راهنمای گارانتی', () => {
  for (const f of pages) { const h = fs.readFileSync(f, 'utf8'); for (const t of ['درباره GMW', 'تماس', 'قوانین', 'حریم خصوصی', 'راهنمای گارانتی']) assert.ok(h.includes('>' + t + '</a>'), path.relative(SITE, f) + ' ← ' + t); }
});

test('پیوندهای داخلی در هر دو خروجی به فایل موجود می‌رسند', () => {
  for (const [dir, web] of [[SITE, true], [OFF, false]]) {
    for (const f of htmlFiles(dir)) {
      const h = fs.readFileSync(f, 'utf8');
      for (const m of h.matchAll(/(?:href|src)="([^"#]+)(?:#[^"]*)?"/g)) {
        const u = m[1]; if (/^(https?:|mailto:|tel:|data:)/.test(u)) continue;
        let target = web ? path.join(dir, u) : path.resolve(path.dirname(f), u);
        if (web && u.endsWith('/')) target = path.join(target, 'index.html');
        assert.ok(fs.existsSync(target), `${path.relative(ROOT, f)} → ${u}`);
      }
    }
  }
});

test('سئو: sitemap شامل صفحات عمومی و بدون admin، robots درست، admin با noindex', () => {
  const sm = read(SITE, 'sitemap.xml'), robots = read(SITE, 'robots.txt');
  const pub = pages.filter((f) => !/admin|404/.test(f));
  assert.equal((sm.match(/<loc>/g) || []).length, pub.length);
  assert.ok(!sm.includes('/admin/'));
  assert.match(robots, /Disallow: \/admin\//); assert.match(robots, /Sitemap: https?:\/\/.+\/sitemap\.xml/);
  assert.match(read(SITE, 'admin/index.html'), /<meta name="robots" content="noindex, nofollow">/);
  assert.match(read(SITE, 'warranty/index.html'), /<meta name="robots" content="index, follow">/);
});

test('داده ساختاریافته: JSON معتبر و بدون ادعای ساختگی (rating/review/price)', () => {
  for (const f of pages) {
    for (const m of fs.readFileSync(f, 'utf8').matchAll(/<script type="application\/ld\+json">(.*?)<\/script>/gs)) {
      const j = JSON.parse(m[1]); const s = JSON.stringify(j);
      assert.ok(j['@context'] === 'https://schema.org');
      assert.ok(!/aggregateRating|"review"|"offers"|"price"|telephone|address/.test(s), path.relative(SITE, f));
    }
  }
  assert.match(read(SITE, 'index.html'), /"@type":"FAQPage"/);
});

test('محتوا: عنوان بیمه‌نامه ادعا نمی‌شود و ۲٬۳۴۵٬۰۰۰ به‌عنوان قیمت قطعی نیامده', () => {
  for (const f of pages) {
    const h = fs.readFileSync(f, 'utf8').replace(/<script[\s\S]*?<\/script>/g, '');
    for (const m of h.matchAll(/بیمه‌نامه/g)) { const ctx = h.slice(Math.max(0, m.index - 60), m.index + 40); assert.match(ctx, /نیست|نمی|عنوان|بدون|هیچ|قرارداد|تاریخ پایان|بیمه‌گر|ندارد|ندارید|خیر/, path.relative(SITE, f) + ': ' + ctx); }
    assert.ok(!/۲٬۳۴۵٬۰۰۰|2,345,000/.test(h), path.relative(SITE, f));
  }
  const cov = read(SITE, 'coverage-plan/index.html'); assert.match(cov, /سه‌ساله/); assert.ok(!/شش‌ساله|۶ ?ساله/.test(cov));
  const brake = read(SITE, 'brake-service/index.html'); assert.match(brake, /خود لنت رایگان نیست/); assert.match(brake, /حداکثر ۹ نوبت/);
  assert.match(read(SITE, 'insurance-discount/index.html'), /قرارداد همکاری با هیچ شرکت بیمه‌ای وجود ندارد/);
  assert.match(read(SITE, 'tire/index.html'), /هیچ تعهدی برای فروش/);
  assert.match(read(SITE, 'transparent-fund/index.html'), /نمونهٔ نمایشی/);
});

test('فرم‌ها: هر فیلد ورودی label مرتبط دارد و فیلد موبایل کیبورد عددی', () => {
  for (const f of pages) {
    const h = fs.readFileSync(f, 'utf8');
    for (const m of h.matchAll(/<(?:input|select|textarea)[^>]*\bid="(f-[^"]+)"/g)) assert.ok(h.includes(`for="${m[1]}"`), `${path.relative(SITE, f)} label برای ${m[1]}`);
    for (const m of h.matchAll(/type="tel"[^>]*/g)) assert.match(m[0], /inputmode="numeric"/);
  }
});

test('وزن صفحه: HTML هر صفحه و کل JS/CSS سبک است', () => {
  for (const f of pages) assert.ok(fs.statSync(f).size < 60000, path.relative(SITE, f));
  let total = 0; for (const e of ['css/style.css', 'js/core.js', 'js/app.js', 'js/ai-adapter.js']) total += fs.statSync(path.join(SITE, 'assets', e)).size;
  assert.ok(total < 120000, 'کل دارایی‌های اصلی: ' + total);
  assert.ok(!/@import|fonts\.googleapis|cdn\./.test(read(SITE, 'assets/css/style.css') + read(SITE, 'index.html')), 'بدون وابستگی خارجی');
});
