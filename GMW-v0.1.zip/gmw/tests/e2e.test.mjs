// تست مرورگری واقعی (Chromium با شبیه‌سازی iPhone) روی سایت ساخته‌شده
import test from 'node:test';
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { startServer } from '../build/serve.mjs';
const require = createRequire(import.meta.url);
let pw;
for (const p of ['playwright', '/home/claude/.npm-global/lib/node_modules/playwright']) { try { pw = require(p); break; } catch (e) {} }
const skip = !pw && 'playwright در دسترس نیست';

const PORT = 4179, BASE = `http://127.0.0.1:${PORT}`;
let server, browser;
test.before(async () => { if (skip) return; server = await startServer('site', PORT); browser = await pw.chromium.launch(); });
test.after(async () => { if (browser) await browser.close(); if (server) server.close(); });

async function page(path, { device = 'iPhone 13' } = {}) {
  const ctx = await browser.newContext({ ...pw.devices[device] });
  const p = await ctx.newPage(); const errors = [];
  p.on('pageerror', (e) => errors.push(e.message)); p.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
  await p.goto(BASE + path); p.errors = errors; p.ctx = ctx; return p;
}
const fill = async (p, o, scope = '') => { for (const [k, v] of Object.entries(o)) { const el = p.locator(`${scope} [name="${k}"]`.trim()).first(); const tag = await el.evaluate((n) => n.tagName); if (tag === 'SELECT') await el.selectOption(v); else await el.fill(v); } };

test('موبایل: بدون اسکرول افقی صفحه و بدون خطای JS در همهٔ صفحات', { skip }, async () => {
  for (const u of ['/', '/warranty/', '/coverage-plan/', '/brake-service/', '/transparent-fund/', '/club/', '/economy-basket/', '/tire/', '/ai-engineer/', '/insurance-discount/', '/contact/', '/about/', '/terms/', '/privacy/', '/warranty-guide/', '/admin/']) {
    const p = await page(u); await p.waitForLoadState('networkidle');
    const over = await p.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
    assert.ok(over <= 1, `${u} اسکرول افقی ${over}px`);
    assert.deepEqual(p.errors, [], u); await p.ctx.close();
  }
});

test('موبایل: کارت‌های خدمات افقی و قابل ورق‌زدن؛ دسکتاپ: شبکهٔ منظم', { skip }, async () => {
  let p = await page('/'); const m = await p.evaluate(() => { const c = document.querySelector('.cards'); return { ox: getComputedStyle(c).overflowX, disp: getComputedStyle(c).display, scroll: c.scrollWidth > c.clientWidth, n: c.children.length, dir: getComputedStyle(document.body).direction }; });
  assert.equal(m.ox, 'auto'); assert.ok(m.scroll); assert.equal(m.n, 8); assert.equal(m.dir, 'rtl'); await p.screenshot({ path: 'tests/shots/home-iphone.png' }); await p.ctx.close();
  p = await page('/', { device: 'Desktop Chrome' }); const d = await p.evaluate(() => { const c = document.querySelector('.cards'); return { disp: getComputedStyle(c).display, cols: getComputedStyle(c).gridTemplateColumns.split(' ').length }; });
  assert.equal(d.disp, 'grid'); assert.equal(d.cols, 4); await p.screenshot({ path: 'tests/shots/home-desktop.png' }); await p.ctx.close();
});

test('منوی موبایل باز و بسته می‌شود', { skip }, async () => {
  const p = await page('/'); assert.equal(await p.locator('#nav').isVisible(), false);
  await p.click('#menu-btn'); assert.equal(await p.locator('#nav').isVisible(), true); assert.equal(await p.getAttribute('#menu-btn', 'aria-expanded'), 'true');
  await p.click('#menu-btn'); assert.equal(await p.locator('#nav').isVisible(), false); await p.ctx.close();
});

test('فعال‌سازی گارانتی: ثبت موفق، سپس رد کد مصرف‌شده و سریال تکراری، و استعلام', { skip }, async () => {
  const p = await page('/warranty/'); const data = { scratchCode: 'GMW-DEMO-1001', serial: 'SER-9001', partName: 'کمک‌فنر', brand: 'نمونه', vehicleModel: 'دنا', vehicleYear: '1400', purchaseDate: '2026-10-25', buyerName: 'تست', buyerPhone: '۰۹۱۲۱۲۳۴۵۶۷', seller: 'فروشگاه' };
  const run = async (o) => { await fill(p, { ...data, ...o }); await p.setInputFiles('input[name=invoice]', { name: 'inv.png', mimeType: 'image/png', buffer: Buffer.from('x') }); await p.click('#warranty-form button[type=submit]'); };
  await run({}); const ok = await p.locator('#warranty-form .result.ok').innerText(); const code = ok.match(/GMW-W-[A-Z0-9]{6}/)[0];
  assert.match(ok, /در انتظار بررسی فاکتور/);
  await run({ serial: 'SER-9002' }); assert.match(await p.locator('[data-err=scratchCode]').first().innerText(), /قبلاً استفاده/);
  await run({ scratchCode: 'GMW-DEMO-1002', serial: 'ser 9001' }); assert.match(await p.locator('#warranty-form [data-err=serial]').innerText(), /قبلاً ثبت/);
  await p.fill('#warranty-lookup input[name=q]', code); await p.click('#warranty-lookup button[type=submit]'); assert.match(await p.locator('#warranty-lookup .result').innerText(), /کمک‌فنر/);
  assert.match(await p.locator('#demo-codes li').first().textContent(), /مصرف‌شده/);
  const st = JSON.parse(await p.evaluate(() => localStorage.getItem('gmw_demo_state_v1'))); assert.equal(st.warranties.length, 1);
  await p.screenshot({ path: 'tests/shots/warranty-iphone.png', fullPage: true }); assert.deepEqual(p.errors, []); await p.ctx.close();
});

test('طرح سه‌ساله: قیمت لحظه‌ای، ثبت، کد رهگیری و پیگیری', { skip }, async () => {
  const p = await page('/coverage-plan/'); assert.equal(await p.locator('input[name=parts]').count(), 19);
  assert.equal(await p.locator('#total-bar').isHidden(), true);
  await p.check('input[value=p01]'); await p.check('input[value=p07]');
  assert.match(await p.locator('#total-amount').innerText(), /۷۲۰٬۰۰۰/); assert.equal(await p.locator('#total-bar').isVisible(), true);
  await p.uncheck('input[value=p07]'); assert.match(await p.locator('#total-amount').innerText(), /۶۰۰٬۰۰۰/); await p.check('input[value=p07]');
  await p.click('#coverage-form button[type=submit]'); assert.match(await p.locator('[data-err=acceptTerms]').innerText(), /الزامی/);
  await fill(p, { name: 'سارا', phone: '09121112233', city: 'تهران', address: 'خیابان نمونه', model: 'دنا', year: '1400', mileage: '45000', accident: 'ندارد' });
  await p.check('input[name=acceptTerms]'); await p.click('#coverage-form button[type=submit]');
  const t = await p.locator('#coverage-form .result.ok').innerText(); assert.match(t, /آزمایشی/); const code = t.match(/GMW-C-[A-Z0-9]{6}/)[0];
  assert.match(await p.locator('#coverage-result').innerText(), /معرفی استادکار/);
  await p.fill('#coverage-track input[name=q]', code); await p.click('#coverage-track button[type=submit]'); assert.match(await p.locator('#coverage-track .result').innerText(), /پرداخت آزمایشی/);
  await p.screenshot({ path: 'tests/shots/coverage-iphone.png', fullPage: true }); assert.deepEqual(p.errors, []); await p.ctx.close();
});

const seedMember = (phone) => `(()=>{const C=window.GMWCore;const s=JSON.parse(localStorage.getItem('gmw_demo_state_v1'))||C.defaultState();C.joinClub(s,{name:'عضو تست',phone:'${phone}'});localStorage.setItem('gmw_demo_state_v1',JSON.stringify(s));})()`;

test('لنت: سه درخواست مجاز، چهارم رد؛ نمایش «رایگان» برای اجرت', { skip }, async () => {
  const p = await page('/brake-service/'); await p.evaluate(seedMember('09125550001')); await p.reload();
  assert.match(await p.locator('#brake-labor').innerText(), /رایگان/); assert.equal(await p.locator('#brake-prices .price-row').count(), 3);
  assert.equal(await p.locator('.slots .year').count(), 3); assert.equal(await p.locator('.slots i').count(), 9);
  const req = async () => { await fill(p, { name: 'عضو تست', phone: '09125550001', city: 'تهران', model: 'سمند', year: '1395', padClass: 'c2' }, '#brake-form'); await p.locator('#brake-form [name=centerId]').selectOption({ index: 1 }); await p.click('#brake-form button[type=submit]'); };
  for (let i = 0; i < 3; i++) { await req(); assert.match(await p.locator('#brake-form .result.ok').innerText(), /GMW-B-/); }
  await req(); assert.match(await p.locator('#brake-form .result.bad').innerText(), /سهمیهٔ سال ۱.*تکمیل/);
  await p.fill('#brake-quota input[name=phone]', '09125550001'); await p.click('#brake-quota button[type=submit]'); assert.match(await p.locator('#brake-quota .result').innerText(), /۳.*۳.*۰/s);
  await p.screenshot({ path: 'tests/shots/brake-iphone.png', fullPage: true }); assert.deepEqual(p.errors, []); await p.ctx.close();
});

test('صندوق شفاف: همهٔ ردیف‌ها نمونهٔ نمایشی و فیلتر کار می‌کند', { skip }, async () => {
  const p = await page('/transparent-fund/'); const rows = p.locator('#fund-table tbody tr'); assert.equal(await rows.count(), 6);
  for (let i = 0; i < 6; i++) assert.match(await rows.nth(i).innerText(), /نمونه نمایشی/);
  await p.selectOption('#fund-filter', 'رد'); assert.equal(await rows.count(), 1);
  assert.match(await p.locator('.notice.demo').innerText(), /نمونهٔ نمایشی/); await p.screenshot({ path: 'tests/shots/fund-iphone.png' }); await p.ctx.close();
});

test('باشگاه: عضویت، ورود، افزودن خودرو و خروج', { skip }, async () => {
  const p = await page('/club/'); assert.equal(await p.locator('#club-member').isHidden(), true);
  await fill(p, { 'name': 'مریم', }); await p.locator('#club-join [name=phone]').fill('09127778899'); await p.click('#club-join button[type=submit]');
  assert.equal(await p.locator('#club-member').isVisible(), true); assert.match(await p.locator('#m-name').innerText(), /مریم/); assert.match(await p.locator('#m-quota').innerText(), /۳ نوبت از ۳/);
  const st = JSON.parse(await p.evaluate(() => localStorage.getItem('gmw_demo_state_v1'))); assert.equal(st.clubMembers[0].consentMarketing, false);
  await p.locator('#club-vehicle [name=vehicleModel]').fill('تیبا'); await p.click('#club-vehicle button[type=submit]'); assert.match(await p.locator('#m-vehicles').innerText(), /تیبا/);
  await p.click('#m-logout'); assert.equal(await p.locator('#club-guest').isVisible(), true); assert.deepEqual(p.errors, []); await p.ctx.close();
});

test('فرم‌های لاستیک/سبد/بیمه/تماس: خطای رضایت و ثبت موفق', { skip }, async () => {
  let p = await page('/tire/'); await fill(p, { name: 'م', phone: '09121234567', city: 'قم', model: 'تیبا', year: '1399', size: '205/60R15' });
  await p.click('#tire-form button[type=submit]'); assert.match(await p.locator('[data-err=consentNotify]').innerText(), /رضایت/);
  await p.check('input[name=consentNotify]'); await p.click('#tire-form button[type=submit]'); assert.match(await p.locator('#tire-form .result.ok').innerText(), /وعدهٔ فروش یا تحویل نیست/); await p.ctx.close();
  p = await page('/economy-basket/'); await p.click('#basket-form button[type=submit]'); assert.ok((await p.locator('[data-err=categories]').innerText()).length > 0);
  await p.check('input[value="لنت"]', { force: true }); await fill(p, { model: 'پژو ۲۰۶', year: '1398', phone: '09121234567' }); await p.check('input[name=consentNotify]'); await p.click('#basket-form button[type=submit]'); assert.match(await p.locator('#basket-form .result.ok').innerText(), /GMW-S-/); await p.ctx.close();
  p = await page('/insurance-discount/'); await fill(p, { name: 'ع', phone: '09121234567', model: 'دنا', insurer: 'ندارم' }); await p.check('input[name=consentNotify]'); await p.click('#insurance-form button[type=submit]'); assert.match(await p.locator('#insurance-form .result.ok').innerText(), /تخفیفی تضمین نمی‌شود/); await p.ctx.close();
  p = await page('/contact/'); await fill(p, { name: 'ع', phone: '09121234567', subject: 'سایر', message: 'سلام، یک پیام آزمایشی کافی' }); await p.click('#contact-form button[type=submit]'); assert.match(await p.locator('#contact-form .result.ok').innerText(), /GMW-M-/); assert.deepEqual(p.errors, []); await p.ctx.close();
});

test('مهندس خودرو: خروجی ساختاریافته و سلب مسئولیت', { skip }, async () => {
  const p = await page('/ai-engineer/'); await p.fill('#f-symptoms', 'هنگام ترمز صدای جیرجیر می‌آید و فرمان می‌لرزد');
  await p.click('#ai-form button[type=submit]'); await p.waitForSelector('#ai-result .panel'); const t = await p.locator('#ai-result').innerText();
  for (const w of ['میزان فوریت', 'علت‌های احتمالی', 'قطعات نیازمند بررسی', 'سؤالات تکمیلی', 'تشخیص قطعی نیست']) assert.ok(t.includes(w), w);
  await p.screenshot({ path: 'tests/shots/ai-iphone.png', fullPage: true }); assert.deepEqual(p.errors, []); await p.ctx.close();
});

test('پنل مدیریت: گردش کامل پوشش، رد با بازپرداخت، قیمت‌گذاری، سهمیه و دسترسی نقش‌ها', { skip }, async () => {
  const p = await page('/admin/', { device: 'Desktop Chrome' });
  await p.evaluate(() => { const C = window.GMWCore, s = C.defaultState(); const a = C.createCoverageRequest(s, { parts: ['p01', 'p07'], acceptTerms: true, owner: { name: 'الف', phone: '09120000011', city: 'تهران', address: 'آ', model: 'دنا', year: '1400', mileage: '1000', accident: 'ندارد' } });
    C.createCoverageRequest(s, { parts: ['p10'], acceptTerms: true, owner: { name: 'ب', phone: '09120000022', city: 'مشهد', address: 'آ', model: 'تیبا', year: '1399', mileage: '2000', accident: 'جزئی' } });
    localStorage.setItem('gmw_demo_state_v1', JSON.stringify(s)); }); await p.reload();
  await p.click('[data-tab=coverage]'); const rows = p.locator('.table tbody tr'); assert.equal(await rows.count(), 2);
  const first = rows.nth(1); // قدیمی‌ترین پایین‌تر است
  await first.locator('select[data-tech]').selectOption({ index: 1 }); await first.locator('[data-act=assign]').click();
  await p.locator('.table tbody tr').nth(1).locator('[data-note]').fill('معاینه سالم'); await p.locator('.table tbody tr').nth(1).locator('[data-act=inspect]').click();
  await p.locator('.table tbody tr').nth(1).locator('[data-act=approve]').click(); await p.locator('.table tbody tr').nth(1).locator('[data-act=activate]').click();
  assert.match(await p.locator('.table tbody tr').nth(1).innerText(), /پوشش فعال است/);
  const second = p.locator('.table tbody tr').nth(0); await second.locator('[data-act=reject]').click(); assert.match(await p.locator('#admin-msg').innerText(), /دلیل رد/);
  await p.locator('.table tbody tr').nth(0).locator('[data-why]').fill('خودرو قبلاً دچار تصادف شدید شده'); await p.locator('.table tbody tr').nth(0).locator('[data-act=reject]').click();
  await p.click('[data-tab=payments]'); assert.match(await p.locator('.admin-sec').nth(1).innerText(), /۹۰۰٬۰۰۰ تومان/); await p.click('[data-act=refund]'); assert.match(await p.locator('#admin-msg').innerText(), /بازپرداخت ثبت شد/);
  await p.click('[data-tab=parts]'); await p.locator('input[data-part=p01][data-k=price]').fill('700000'); await p.locator('input[data-part=p01][data-k=price]').dispatchEvent('change');
  await p.click('[data-tab=brake]'); assert.match(await p.locator('.table').nth(1).innerText(), /09120000011/);
  await p.click('[data-tab=audit]'); const au = await p.locator('.table tbody').innerText(); assert.match(au, /edit-part/); assert.match(au, /reject/); assert.match(au, /refund/);
  const price = JSON.parse(await p.evaluate(() => localStorage.getItem('gmw_demo_state_v1'))).parts[0].price; assert.equal(price, 700000);
  await p.selectOption('#role', 'support'); assert.equal(await p.locator('[data-tab=payments]').count(), 0); assert.ok(await p.locator('[data-tab=customers]').count());
  await p.selectOption('#role', 'finance'); assert.equal(await p.locator('[data-tab=coverage]').count(), 0); assert.ok(await p.locator('[data-tab=payments]').count());
  assert.deepEqual(p.errors, []); await p.ctx.close();
});

test('قیمت ویرایش‌شدهٔ مدیر در صفحهٔ عمومی اعمال می‌شود', { skip }, async () => {
  const p = await page('/coverage-plan/'); await p.evaluate(() => { const s = JSON.parse(localStorage.getItem('gmw_demo_state_v1')); s.parts[0].price = 777000; localStorage.setItem('gmw_demo_state_v1', JSON.stringify(s)); }); await p.reload();
  await p.check('input[value=p01]'); assert.match(await p.locator('#total-amount').innerText(), /۷۷۷٬۰۰۰/); await p.ctx.close();
});
